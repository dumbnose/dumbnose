//
// Simple wrapper around the Win32 CreateThread call.  Just as with
// CreateThread, you need to ensure you don't hand the function a
// pointer or reference that can potentially go out of scope before
// the function runs.
//
// Also note that the use of bind and function cause non-ref
// arguments to get copied quite a few times.  Therefore, refs or
// shared_ptr's should be used for expensive to copy objects.
//

#pragma once

#include <windows.h>
#include <boost/function.hpp>
#include <boost/bind.hpp>
#include <boost/scoped_ptr.hpp>

namespace dumbnose {

DWORD WINAPI create_thread_indirect(void* param)
{
	// Take ownership of the function object
	boost::scoped_ptr<boost::function<void(void)> > 
		func(static_cast<boost::function<void(void)>*>(param));

	// Call the function
	(*func)();

	return 0;
}

bool create_thread(boost::function<void(void)> functor)
{
	boost::function<void(void)>* func = new boost::function<void(void)>;
	*func = functor;

	HANDLE thread = CreateThread(NULL,0,&create_thread_indirect,func,0,NULL);
	if(NULL==thread) return false;

	CloseHandle(thread);
	return true;
}


} // namespace dumbnose